<?php
/**
 * 'middleware'=>'checkAdmin' //中间件
 */
Route::group(['namespace'=>'admin'],function(){
    /**
     * 首页
     */
    Route::any('index','indexController@index');
    /**
     * 用户
     */
    Route::any('admin/user','userController@index');
    Route::any('user/lists','userController@lists');
    /**
     * 模板消息
     */
    Route::any('admin/template','templateController@index');
    Route::any('template/lists','templateController@lists');
    Route::any('template/add','templateController@add');
    Route::any('template/edit/{id}','templateController@edit');
    Route::any('template/delete/{id}','templateController@delete');
    /**
     * 通知
     */
    Route::any('admin/notice','noticeController@index');
    Route::any('notice/lists','noticeController@lists');
    Route::any('notice/add','noticeController@add');
    Route::any('notice/edit/{id}','noticeController@edit');
    Route::any('notice/delete/{id}','noticeController@delete');

    /**
     * banner图
     */
    Route::any('admin/banner','bannerController@index');
    Route::any('banner/insert','bannerController@insert');
    /**
     * 投诉
     */
    Route::any('admin/complaint','complaintController@index');
    Route::any('complaint/lists','complaintController@lists');
    /**
     * 常见问题
     */
    Route::any('admin/question','questionController@question');
    Route::any('question/lists',"questionController@questionLists");
    Route::any('question/insert',"questionController@questionInsert");
    Route::any('question/delete/{id}',"questionController@questionDel");
    Route::any('question/edit/{id}',"questionController@questionEdit");
    /**
     * 车主头条
     */
    Route::any('admin/headlines','headlinesController@index');
    Route::any('headlines/lists',"headlinesController@lists");
    Route::any('headlines/add',"headlinesController@add");
    Route::any('headlines/edit/{id}',"headlinesController@edit");
    Route::any('headlines/delete/{id}',"headlinesController@delete");
    /**
     * 订单
     */
    Route::any('admin/order','orderController@index');
    Route::any('admin/pay','orderController@pay');
    Route::any('admin/unpaid','orderController@unpaid');
    Route::any('admin/complete','orderController@complete');
    Route::any('admin/fail','orderController@fail');
    Route::any('order/lists','orderController@lists');
    Route::any('order/list/{type}','orderController@list');
    Route::any('order/notify','orderController@notify');



    /**
     * 配置
     */
    Route::any('admin/config','configController@index');
    Route::any('config/insert','configController@insert');


});
Route::any('/','admin\indexController@index');
Route::any('upload','admin\indexController@upload'); //上传图片
Route::any('update','admin\indexController@update'); //上传文件
Route::any('editUpload','admin\indexController@editUpload'); //文本编辑的图片上传