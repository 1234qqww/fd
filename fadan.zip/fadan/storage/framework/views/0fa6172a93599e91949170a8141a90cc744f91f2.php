<?php $__env->startSection('title'); ?>
    用户
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mind'); ?>
    用户
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="layui-card">
        <div class="layui-card-body">
            <div class="layui-form toolbar">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <input id="edtSearch" class="layui-input" type="text" placeholder="输入openid"/>
                    </div>
                    <div class="layui-inline">
                        <button id="btnSearch" class="layui-btn layui-btn-normal icon-btn layui-btn-sm"><i class="layui-icon">&#xe615;</i>搜索</button></div>
                </div>
            </div>
            <table class="layui-table" id="userTable" lay-filter="userTable"></table>
        </div>
    </div>
    <!-- 表格操作列 -->
    <script>
        layui.use(['layer', 'form', 'table', 'util', 'admin', 'formSelects'], function () {
            var $ = layui.jquery;
            var layer = layui.layer;
            var form = layui.form;
            var table = layui.table;
            var util = layui.util;
            var admin = layui.admin;
            var formSelects = layui.formSelects;
            // 渲染表格
            var insTb = table.render({
                elem: '#userTable',
                skin:'line',
                url: "<?php echo e(url('user/lists')); ?>",
                page: true,
                cols: [[
                    {field: 'id',align:"center",title:"id"},
                    {field: 'openid', title: 'openid',align:"center"},
                    {field: 'payorder', title: '已支付',align:"center"},
                    {field: 'nopayorder', title: '待处理',align:"center"},
                    {field: 'updated_at', title: '最后登陆时间',align:"center"},
                ]]
            });
            // 搜索
            $('#btnSearch').click(function () {
                var value = $('#edtSearch').val();
                insTb.reload({where: { key: value}});
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/public/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpstudy\PHPTutorial\WWW\fadan\resources\views/admin/user/index.blade.php ENDPATH**/ ?>