<link rel="stylesheet" href="<?php echo e(asset('easyweb/assets/libs/layui/css/layui.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('easyweb/assets/module/admin.css?v=304')); ?>"/>
<script type="text/javascript" src="<?php echo e(asset('easyweb/assets/libs/jquery/jquery-3.2.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('easyweb/assets/libs/layui/layui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('easyweb/assets/js/common.js?v=304')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/wangEditor.min.js')); ?>"></script>
<form id="modelUserForm" lay-filter="modelUserForm" class="layui-form model-form">
    <input name="userId" type="hidden"/>
    <div class="layui-form-item">
        <label class="layui-form-label">标题</label>
        <div class="layui-input-block">
            <input name="username" id="name" placeholder="请输入标题" type="text" class="layui-input" maxlength="20"
                   lay-verType="tips" lay-verify="required" required value="<?php echo e($info['name']); ?>"/>
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">内容</label>
        <div class="layui-input-block">
            <div id="editor">
            </div>
            <button id="btn1" hidden>获取html</button>
            <input type="text" id="content" hidden value="<?php echo e($info['content']); ?>">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">排序</label>
        <div class="layui-input-block">
            <input name="sort" id="sort" placeholder="请输入位置" type="text" class="layui-input" maxlength="20"
                   lay-verType="tips" lay-verify="required" value="<?php echo e($info['sort']); ?>" required/>
        </div>
    </div>
</form>
<script>
    layui.use(['layer', 'form', 'table', 'util', 'admin', 'formSelects'], function () {
        var $ = layui.jquery;
        var layer = layui.layer;
        var form = layui.form;
        var table = layui.table;
        var util = layui.util;
        var admin = layui.admin;
        var formSelects = layui.formSelects;

    });

    //第一步是先获取服务器传过来的图文信息值
    var info1 = document.getElementById("content").value;
    //把图文信息的值通过innerHTML赋值给编辑器
    document.getElementById("editor").innerHTML=info1;

    var E = window.wangEditor
    var editor = new E('#editor')
    // 或者 var editor = new E( document.getElementById('editor') )
    // 隐藏“网络图片”tab
    editor.customConfig.showLinkImg = false;
    editor.customConfig.uploadFileName = 'file';
    editor.customConfig.uploadImgMaxLength = 5;
    editor.customConfig.uploadImgServer = ""  // 上传图片到服务器
    editor.customConfig.uploadImgServer = "<?php echo e(url('editUpload')); ?>"  // 上传图片到服务器

    editor.create()
    document.getElementById('btn1').addEventListener('click', function () {
        // 读取 html
        console.log(editor.txt.html());
        var html = editor.txt.html();
        $('#content').val(html);
    })
</script>
<?php /**PATH D:\phpstudy\PHPTutorial\WWW\fadan\resources\views/admin/helpcenter/helpcenter_update.blade.php ENDPATH**/ ?>