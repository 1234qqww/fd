<link rel="stylesheet" href="<?php echo e(asset('easyweb/assets/libs/layui/css/layui.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('easyweb/assets/module/admin.css?v=304')); ?>"/>
<script type="text/javascript" src="<?php echo e(asset('easyweb/assets/libs/jquery/jquery-3.2.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('easyweb/assets/libs/layui/layui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('easyweb/assets/js/common.js?v=304')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/wangEditor.min.js')); ?>"></script>
<form id="modelUserForm" lay-filter="modelUserForm" class="layui-form model-form">
    <input name="userId" type="hidden"/>
    <div class="layui-form-item">
        <label class="layui-form-label">标题</label>
        <div class="layui-input-block">
            <input name="title" id="title" placeholder="请输入标题" type="text" class="layui-input" maxlength="20"
                   lay-verType="tips" lay-verify="required" value="<?php echo e($info['title']); ?>" required/>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">模板id</label>
        <div class="layui-input-block">
            <input name="template_id" id="template_id" placeholder="请输入模板id" type="text" class="layui-input"
                   lay-verType="tips" lay-verify="required" value="<?php echo e($info['template_id']); ?>" required/>
        </div>
    </div>
</form>
<?php /**PATH D:\phpstudy\PHPTutorial\WWW\fadan\resources\views/admin/template/template_update.blade.php ENDPATH**/ ?>