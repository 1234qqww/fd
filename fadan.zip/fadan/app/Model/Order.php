<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table='order';
    protected $fillable=[
        'id','ordernumber','formid','notice','phone','money','noticetime','type','openid','service','amount','name','overdue','urgent','status','created_at','updated_at'
    ];
    protected $hidden=[
        ''
    ];
    /**
     * @param $param
     * @return array
     * 加急订单
     */
    public function lists($param){
        $page = empty($param['page'])?0:$param['page'];
        $limit = empty($param['limit'])?20:$param['limit'];
        $query = $this;
        if(!empty($param['key'])){
            $query = $query -> where('name','like',"%{$param['key']}%");
        }
        $offset = ($page-1)*$limit;
        $tot = $query->get()->count();
        $data = $query->offset($offset)->limit($limit)->where('type',1)->where('status',1)->orderBy('id','Desc')->get();
        return ['data'=>$data,'count'=>$tot];
    }
    /**
     * @param $param
     * @return array
     * 订单列表
     */
    public function list($param){
        $page = empty($param['page'])?0:$param['page'];
        $limit = empty($param['limit'])?20:$param['limit'];
        $query = $this;
        if(!empty($param['key'])){
            $query = $query -> where('name','like',"%{$param['key']}%");
        }
        $offset = ($page-1)*$limit;
        $tot = $query->get()->count();
        $data = $query->offset($offset)->limit($limit)->where('status',$param['type'])->orderBy('id','Desc')->get();
        return ['data'=>$data,'count'=>$tot];
    }
    /**
     * 创建订单
     */
    public function add($param){
        $data['ordernumber'] = !empty($param['ordernumber'])? preg_replace('# #','',$param['ordernumber']):'';
        $data['notice'] = !empty($param['notice'])? preg_replace('# #','',$param['notice']):'';
        $data['phone'] = !empty($param['phone'])? preg_replace('# #','',$param['phone']):'';
        $data['money'] = !empty($param['money'])? preg_replace('# #','',$param['money']):'';
        $data['noticetime'] = !empty($param['noticetime'])? preg_replace('# #','',$param['noticetime']):'';
        $data['type'] = isset($param['type'])? preg_replace('# #','',$param['type']):'';
        $data['openid'] = !empty($param['openid'])? preg_replace('# #','',$param['openid']):'';
        $data['service'] = !empty($param['service'])? preg_replace('# #','',$param['service']):'';
        $data['amount'] = !empty($param['amount'])? preg_replace('# #','',$param['amount']):'';
        $data['name'] = !empty($param['name'])? preg_replace('# #','',$param['name']):'';
        $data['overdue'] = !empty($param['overdue'])? preg_replace('# #','',$param['overdue']):'';
        $data['urgent'] = !empty($param['urgent'])? preg_replace('# #','',$param['urgent']):'';
        $data['status'] = isset($param['status'])? preg_replace('# #','',$param['status']):'';
        $data['formid'] = isset($param['formid'])? preg_replace('# #','',$param['formid']):'';
        return $this->create($data);
    }
    /**
     * 修改订单状态
     */
    public function orderupdate($ordernumber,$formid){
        return $this->where('ordernumber',$ordernumber)->update(['status'=>1,'formid'=>$formid]);

    }
    /**
     * 通过订单号查询订单
     */
    public function ordernumber($ordernumber){
        return $this->where('ordernumber',$ordernumber)->first();

    }
}
