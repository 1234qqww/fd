<?php

namespace App\Http\Controllers\admin;

use App\Model\Order;
use App\Model\Config;
use App\Model\Template;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class orderController extends Controller
{
    private $order;
    private $config;
    private $template;
    public function __construct(Order $order,Config $config,Template $template)
    {
        $this->order=$order;
        $this->config=$config;
        $this->template=$template;
    }
    /**
     * 首页
     */
    public function index(){
        return view('admin/order/index');
    }
    public function pay(){
        return view('admin/order/pay');
    }
    public function unpaid(){
        return view('admin/order/unpaid');
    }
    public function complete(){
        return view('admin/order/complete');
    }
    public function fail(){
        return view('admin/order/fail');
    }
    /**
     * 加急数据
     */
    public function lists(Request $request){
        $param=$request->all();
        $data=$this->order->lists($param);
        return $data?state('0','订单列表',$data['data'],$data['count']):state('1','无数据','');
    }
    /**
     * 数据
     */
    public function list(Request $request,$type){
        $param=$request->all();
        $param['type']=$type;
        $data=$this->order->list($param);
        return $data?state('0','订单列表',$data['data'],$data['count']):state('1','无数据','');
    }
    /**
     * 添加订单
     */
    public function orderadd(Request $request){
        //判断参数是否存在
        if(!$request->has('openid') || !$request->has('notice') || !$request->has('name')
            || !$request->has('phone')|| !$request->has('money')|| !$request->has('noticetime')
            || !$request->has('type') || !$request->has('urgent') || !$request->has('service')
            || !$request->has('amount') || !$request->has('overdue') || !$request->has('formid')){
            return state([2,'缺少参数','']);
        }
        $param=$request->all();
        $param['ordernumber']='Z'.date('Ymd') . str_pad(mt_rand(1, 999), 3, '0', STR_PAD_LEFT).$param['openid'];
        $param['status']=0;
        $data=$this->order->add($param);
        return $data?state('0','添加成功',$param):state('1','添加失败','');
    }
    /**
     * 发送待支付模板消息
     */
    public function paytemplate(Request $request){
        $param=$request->all();
        $config=$this->config->oneinfo();
        $path='/pages/index/index';
        $result=templateMessage($config->appid,$config->secret,$config->template_id,$param['openid'],$path,$param['formid'],'11','111','11','11','44');
        echo "<pre>";
        print_r($result);
        echo "</pre>";
    }
    /**
     * 支付订单
     */
    public function payorder(Request $request){
        if(!$request->has('ordernumber') || !$request->has('amount') || !$request->has('openid') || !$request->has('formid')){
            return state(2,'缺少参数','');
        }
        $param = $request->all();
        $config = $this->config->oneInfo();
        $amountmoney = $param['amount'];
        $ordernumber = 'M'.date('YmdHis').rand();
        $openid = $param['openid'];
        $appid = $config->appid;
        $mch_id = $config->mer_id;
        $mch_secret = $config->msecret;
        $notify_url = url('order/notify');//回调地址
        $body= "罚款代缴";
        $attach = json_encode(['ordernumber'=>$param['ordernumber'],'formid'=>$param['formid']]);
        return initiatingPayment($amountmoney,$ordernumber,$openid,$appid,$mch_id,$mch_secret,$notify_url,$body,$attach);
    }
    /**
     * 支付成功
     */
    public function paysuccess(Request $request){
        $param=$request->all();
        $this->order->orderupdate($param['orderupdate'],$param['formid']);
    }
    /**
     * 支付回调
     */
    public function notify(){
        $value = file_get_contents("php://input"); //接收微信参数
        if (!empty($value)) {
            $arr = xmlToArray($value);
            writeLogs($value);
            if($arr['result_code'] == 'SUCCESS' && $arr['return_code'] == 'SUCCESS'){
                $attach = json_decode($arr['attach'], true);
                $money = $arr['total_fee']/100;
                $ordernumber = $attach['ordernumber'];
                $formid = $attach['formid'];
                /**
                 * 执行添加充值记录
                 *
                 * $money
                 * $uid
                 * $order
                 */
                @$this->paysuccess($ordernumber,$formid);
                return 'SUCCESS';
            }else{

            }
        }
    }
}

