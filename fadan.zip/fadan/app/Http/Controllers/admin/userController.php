<?php

namespace App\Http\Controllers\admin;

use App\Model\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class userController extends Controller
{
    private $user;
    public function __construct(User $user)
    {
        $this->user=$user;
    }
    public function index(){
        return view('admin/user/index');
    }
    public function lists(Request $request){
        $param = $request->all();
        $data = $this->user->lists($param);
        return $data? state(0,'用户列表',$data['data'],$data['count']):state(0,'无数据','','');
    }
}
